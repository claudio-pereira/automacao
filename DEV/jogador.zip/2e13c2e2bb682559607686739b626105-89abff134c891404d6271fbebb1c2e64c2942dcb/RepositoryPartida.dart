import 'package:contole_futebol/src/data/DBHelper/DBHelper.dart';
import 'package:contole_futebol/src/models/partida.dart';
import 'package:sqflite/sqflite.dart';

class RepositoryPartida {
  insertPartida(Partida partida) async {
    Database db = await DBHelper.instance.database;

    Map<String, dynamic> row = {
      DBHelper.partidaDescricao: partida.descricao,
      DBHelper.partidaData: partida.data.toString(),      
      DBHelper.partidaSituacao: partida.situacao.toString(),
    };
    await db.insert(DBHelper.tablePartidas, row);
  }  

  Future<List<Partida>> selectPartida() async {
    Database db = await DBHelper.instance.database;
    List<Partida> retorno = [];
    List<Map> partidas =
        await db.rawQuery("SELECT * FROM ${DBHelper.tablePartidas}");

    partidas.forEach((partida) {
      retorno.add(
        Partida(
          id: partida[DBHelper.partidaId],
          descricao: partida[DBHelper.partidaDescricao], 
          data: "",
          situacao: SituacaoPartida.finalizada,
        ),
      );
    });

    return retorno;
  }
}