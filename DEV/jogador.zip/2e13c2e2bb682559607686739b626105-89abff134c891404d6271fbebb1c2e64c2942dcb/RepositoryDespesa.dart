import 'package:contole_futebol/src/data/DBHelper/DBHelper.dart';
import 'package:contole_futebol/src/models/despesa.dart';
import 'package:sqflite/sqflite.dart';

class RepositoryDespesa {
  Future<void> insertDespesa(Despesa despesa) async {
    Database db = await DBHelper.instance.database;

    Map<String, dynamic> row = {
      DBHelper.despesaDescricao: despesa.descricao,
      DBHelper.despesaValor: despesa.valor,
      DBHelper.despesaDataHora: despesa.dataHora.toString(),
    };

    await db.insert(DBHelper.tableDespesas, row);
  }

  Future<List<Despesa>> selectDespesas({int id}) async{
    Database db = await DBHelper.instance.database;

    List<Despesa> retorno = [];
    List<Map> despesas = await db.rawQuery("SELECT * FROM ${DBHelper.tableDespesas}");

    despesas.forEach((despesa){
      retorno.add(
        Despesa(
          id: despesa[DBHelper.despesaId],
          descricao: despesa[DBHelper.despesaDescricao],
          valor: despesa[DBHelper.despesaValor],
          dataHora: despesa[DBHelper.despesaDataHora],
        )
      );
    });

    return retorno;
  }
}