import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DBHelper {
  static final String _nomeDB = "controleFutebol.db";
  static final int _versaoDB = 1;

  static final String tableJogadores = "jogadores";
  static final String jogadorId = "jogador_id";
  static final String jogadorNome = "nome";
  static final String jogadorSituacao = "situacao";
  static final String jogadorSaldo = "saldo";

  static final String tablePartidas = "partidas";
  static final String partidaId = "partida_id";
  static final String partidaData = "data";
  static final String partidaDescricao = "descricao";
  static final String partidaSituacao = "situacao";

  static final String tableDespesas = "despesas";
  static final String despesaId = "despesa_id";
  static final String despesaDescricao = "descricao";
  static final String despesaValor = "valor";
  static final String despesaDataHora = "data_hora";

  // Aplicação do padrão Singleton na classe.
  DBHelper._privateConstructor();
  static final DBHelper instance = DBHelper._privateConstructor();

  // Configurar a intância única da classe.
  static Database _database;
  Future<Database> get database async {
    if (_database != null) return _database;

    _database = await _initDatabase();
    return _database;
  }

  // Abre a base de dados (e cria quando ainda não existir).
  Future<Database> _initDatabase() async {
    
    String caminhoDoBanco = await getDatabasesPath();
    String _banco = _nomeDB;
    String path = join(caminhoDoBanco, _banco);

    return await openDatabase(
      path,
      version: _versaoDB,
      onCreate: _criarBanco,
    );
  }

  Future<void> _criarBanco(Database db, int novaVersao) async {

    List<String> queryes = [
      "CREATE TABLE $tableJogadores ($jogadorId INTEGER PRIMARY KEY, $jogadorNome TEXT, $jogadorSituacao TEXT, $jogadorSaldo FLOAT);",
      "CREATE TABLE $tablePartidas ($partidaId INTEGER PRIMARY KEY, $partidaDescricao TEXT, $partidaData TEXT, $partidaSituacao TEXT);",
      "CREATE TABLE $tableDespesas ($despesaId INTEGER PRIMARY KEY, $despesaDescricao TEXT, $despesaValor FLOAT, $despesaDataHora TEXT);",
    ];

    for (String query in queryes) {
      await db.execute(query);
    }
  }
}