import 'package:contole_futebol/src/data/DBHelper/DBHelper.dart';
import 'package:contole_futebol/src/models/jogador.dart';
import 'package:sqflite/sqflite.dart';

class RepositoryJogador {
  insertJogador(Jogador jogador) async {
    Database db = await DBHelper.instance.database;

    Map<String, dynamic> row = {
      DBHelper.jogadorNome: jogador.nome,
      DBHelper.jogadorSituacao: jogador.situacao.toString(),
    };
    await db.insert(DBHelper.tableJogadores, row);
  }

  Future<List<Jogador>> selectJogador() async {
    Database db = await DBHelper.instance.database;
    List<Jogador> retorno = [];
    List<Map> jogadores =
        await db.rawQuery("SELECT * FROM ${DBHelper.tableJogadores}");

    jogadores.forEach((jogador) {
      retorno.add(
        Jogador(
          id: jogador[DBHelper.jogadorId],
          nome: jogador[DBHelper.jogadorNome],
          //situacao: jogador[DBHelper.jogadorSituacao],
        ),
      );
    });

    return retorno;
  }
}